@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">My Subject</div>

                <div class="panel-body">
                    
                    <table class="table">
                    <thead>
                      <tr>
                        <th>EDP-Code</th>
                        <th>Course No</th>
                        <th>Time</th>
                        <th>Days</th>
                        <th>Room</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>IT-01941</td>
                        <td>SOC SC 1D</td>
                        <td>5:31 - 6:31 PM</td>
                        <td>MWF</td>
                        <td>615</td>
                      </tr>

                      <tr>
                        <td>IT-02600</td>
                        <td>ITELECPHP2(LAB)</td>
                        <td>6:31 - 7:31 PM</td>
                        <td>MWF</td>
                        <td>544</td>
                      </tr>

                      <tr>
                        <td>IT-02600</td>
                        <td>ITELECPHP2</td>
                        <td>6:31 - 7:31 PM</td>
                        <td>MWF</td>
                        <td>530A</td>
                      </tr>

                      <tr>
                        <td>IT-01438</td>
                        <td>MGT1A</td>
                        <td>9:00 - 10:30 AM</td>
                        <td>TTH</td>
                        <td>530B</td>
                      </tr>

                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
