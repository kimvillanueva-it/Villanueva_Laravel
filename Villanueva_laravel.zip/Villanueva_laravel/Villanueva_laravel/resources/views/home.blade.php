@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">About</div>

                <div class="panel-body">

                    I'm Kim Joshua Villanueva, 20 years old. i commonly stay in my room. we could say i'm more of an introvert.
                    i dont like sticking around with people, cause it would only annoy me as much. im a gamer as well, i spend
                    most of my time playing games. i also dream of being professional someday, if ever that happens. id like have
                    to quit schooling and focus on Esport and honing my skills on the game. i read books, i just started reading
                    but i never knew reading was fun. action and fictional, and not the crappy love novels and stuff. Programming...
                    programming has always fascinated me since i was young and has no idea with what the world was. brainless to be
                    exact. but now that i have started to learn programming. its like any kind of language i want to learn. learning
                    is too easy for me, im too advanced and can learn by myself. but im just too lazy to study.


                <br><br>
                <table class="table">
                    <thead>
                      <tr>
                        <th colspan="1">Person Data</th>
                      </tr>
                    </thead>
                    <tbody>
                     <tr>
                        <td>Name</td>
                        <td>{{ Auth::user()->name}}</td>
                    </tr>
                    <tr>
                        <td>City Address</td>
                        <td>894 D Jakosalem Street Cebu City</td>
                    </tr>
                    <tr>
                        <td>Telephone</td>
                        <td>09205445239</td>
                    </tr>
                    <tr>
                        <td>E-mail</td>
                        <td>{{ Auth::user()->email}}</td>
                    </tr>
                    </tbody>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
