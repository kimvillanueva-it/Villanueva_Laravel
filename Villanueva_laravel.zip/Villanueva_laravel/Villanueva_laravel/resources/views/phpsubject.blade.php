@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">PHP Subject</div>

                <div class="panel-body">
                   
                    
                    this website is my php2 subject, i learned so much about this subject. every lecture is a new
                    data to be added, and a memory that ill carry until i work in a company. i know this is not 
                    much but if it wasnt for this subject. i would be too lazy to learn about the fundamentals of
                    web programming. this subject helped me a lot, in learning about what and how web programming is. 
                    

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
