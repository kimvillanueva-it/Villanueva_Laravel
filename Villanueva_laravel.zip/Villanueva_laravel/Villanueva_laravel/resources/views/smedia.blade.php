@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><center>Social Media: {{ Auth::user()->name}}</center></div>

                <div class="panel-body">
                   
                <center>
                    <a href="https://www.facebook.com/khiyumi.hsu" style="text-decoration: none;"><img src="{{ asset('image/facebook.png')}}" style="width: 50px; border-radius: 50%"> </a> 

                    <a href="https://github.com/villacala" style="text-decoration: none;"><img src="{{ asset('image/github.png')}}" style="width: 65px; border-radius: 50%"> </a> 

                    <!-- <a href="https://www.instagram.com/kim_joshua_villanueva/" style="text-decoration: none;"><img src="{{ asset('image/instagram.png')}}" style="width: 50px; border-radius: 50%"> </a> -->

                    <a href="http://steamcommunity.com/profiles/76561198161552638" style="text-decoration: none;"><img src="{{ asset('image/steam.png')}}" style="width: 50px; border-radius: 50%"> </a> 

                    <a href="https://plus.google.com/115743325102547668978" style="text-decoration: none;"><img src="{{ asset('image/googleplus.png')}}" style="width: 50px; border-radius: 50%"> </a> 
                </center>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
