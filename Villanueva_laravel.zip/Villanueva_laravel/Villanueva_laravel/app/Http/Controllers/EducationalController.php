<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EducationalController extends Controller
{
    public function EBackground()
    {
    	return view('/educationalbackground');
    }
}
