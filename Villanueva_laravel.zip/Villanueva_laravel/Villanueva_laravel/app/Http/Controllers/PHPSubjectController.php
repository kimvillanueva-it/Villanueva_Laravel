<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PHPSubjectController extends Controller
{
    public function PhpSubject(){
    	return view('/phpsubject');
    }
}
