<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SocialController extends Controller
{
   	
   	public function media()
   	{
   		return view('/smedia');
   	}
}
