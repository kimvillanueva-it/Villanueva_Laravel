<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">About</div>

                <div class="panel-body">

                   <table class="table">
                    <thead>
                      <tr>
                        <th colspan="1">Person Data</th>
                      </tr>
                    </thead>
                    <tbody>
                     <tr>
                        <td>Name</td>
                        <td><?php echo e(Auth::user()->name); ?></td>
                    </tr>
                    <tr>
                        <td>City Address</td>
                        <td>894 D Jakosalem Street Cebu City</td>
                    </tr>
                    <tr>
                        <td>Telephone</td>
                        <td>09205445239</td>
                    </tr>
                    <tr>
                        <td>E-mail</td>
                        <td><?php echo e(Auth::user()->email); ?></td>
                    </tr>
                    </tbody>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>