<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Educational Background</div>

                <div class="panel-body">
                   

                   <table class="table">
                    <thead>
                      <tr>
                        <th>Description</th>
                        <th>School</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td> Secondary-education:</td>
                        <td> First Baptist Church Christian School Incoporated</td>
                    </tr>
                    <tr>
                        <td> university-education:</td>
                        <td> University of Cebu</td>
                    </tr>
                    </tbody>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>